package com.qbot.allmarket;

import android.app.*;import android.os.*;import android.graphics.Color;import android.view.*;import android.widget.*;import org.json.*;import java.io.*;import java.net.*;import java.util.*;

public class MainActivity extends Activity {
 Spinner market, tf; EditText symbol; TextView status,result; Button analyze;
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);
  market=findViewById(R.id.marketSpinner);tf=findViewById(R.id.timeframeSpinner);symbol=findViewById(R.id.symbolInput);status=findViewById(R.id.statusText);result=findViewById(R.id.resultText);analyze=findViewById(R.id.analyzeButton);
  market.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Crypto","Forex","Stocks"}));
  tf.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"15m","1h","4h","1d"}));
  symbol.setText("BTCUSDT"); analyze.setOnClickListener(v->runAnalysis());
 }
 void runAnalysis(){String m=market.getSelectedItem().toString(),s=symbol.getText().toString().trim().toUpperCase(); if(s.isEmpty()){symbol.setError("Enter symbol");return;} status.setText("Fetching market data…"); analyze.setEnabled(false); new Thread(()->{try{double[][] c=fetch(m,s,tf.getSelectedItem().toString()); String out=signal(c,s); runOnUiThread(()->{result.setText(out);status.setText("Analysis complete");analyze.setEnabled(true);});}catch(Exception e){runOnUiThread(()->{result.setText("⚠️ "+e.getMessage());status.setText("Data unavailable");analyze.setEnabled(true);});}}).start();}
 double[][] fetch(String m,String s,String t)throws Exception{
  String u; if(m.equals("Crypto")){String iv=t.equals("15m")?"15m":t.equals("1h")?"1h":t.equals("4h")?"4h":"1d";u="https://api.binance.com/api/v3/klines?symbol="+s+"&interval="+iv+"&limit=250";}
  else {String y=s; if(m.equals("Forex") && s.length()==6)y=s.substring(0,3)+s.substring(3)+"=X"; String range=t.equals("1d")?"1y":"5d";String interval=t.equals("15m")?"15m":t.equals("1h")?"60m":t.equals("4h")?"1h":"1d";u="https://query1.finance.yahoo.com/v8/finance/chart/"+URLEncoder.encode(y,"UTF-8")+"?range="+range+"&interval="+interval;}
  HttpURLConnection x=(HttpURLConnection)new URL(u).openConnection();x.setRequestProperty("User-Agent","Mozilla/5.0");x.setConnectTimeout(10000);x.setReadTimeout(15000);if(x.getResponseCode()!=200)throw new Exception("Market API returned "+x.getResponseCode());BufferedReader r=new BufferedReader(new InputStreamReader(x.getInputStream()));StringBuilder q=new StringBuilder();String z;while((z=r.readLine())!=null)q.append(z);r.close();
  ArrayList<double[]> a=new ArrayList<>();JSONObject root=new JSONObject(q.toString());if(m.equals("Crypto")){JSONArray ks=root;for(int i=0;i<ks.length();i++){JSONArray k=ks.getJSONArray(i);a.add(new double[]{k.getDouble(1),k.getDouble(2),k.getDouble(3),k.getDouble(4),k.getDouble(5)});}}
  else {JSONObject res=root.getJSONObject("chart").getJSONArray("result").getJSONObject(0);JSONObject qq=res.getJSONObject("indicators").getJSONArray("quote").getJSONObject(0);JSONArray o=qq.getJSONArray("open"),h=qq.getJSONArray("high"),l=qq.getJSONArray("low"),c=qq.getJSONArray("close"),v=qq.getJSONArray("volume");for(int i=0;i<c.length();i++)if(!c.isNull(i)&&!o.isNull(i)&&!h.isNull(i)&&!l.isNull(i))a.add(new double[]{o.getDouble(i),h.getDouble(i),l.getDouble(i),c.getDouble(i),v.isNull(i)?0:v.getDouble(i)});}
  if(a.size()<60)throw new Exception("Not enough candles for "+s); double[][] out=new double[a.size()][5];for(int i=0;i<a.size();i++)out[i]=a.get(i);return out;
 }
 String signal(double[][] d,String s){int n=d.length;double ema20=ema(d,3,20),ema50=ema(d,3,50);double r=rsi(d,14), atr=atr(d,14);double close=d[n-1][3];double hi=Double.NEGATIVE_INFINITY,lo=Double.POSITIVE_INFINITY;for(int i=Math.max(0,n-21);i<n-1;i++){hi=Math.max(hi,d[i][1]);lo=Math.min(lo,d[i][2]);}int buy=0,sell=0;if(close>ema20)buy++;else sell++;if(ema20>ema50)buy++;else sell++;if(r>=50&&r<=70)buy++;if(r>=30&&r<=50)sell++;double avg=0;for(int i=Math.max(0,n-20);i<n;i++)avg+=d[i][4];avg/=Math.min(20,n);if(d[n-1][4]>avg){if(close>d[n-1][0])buy++;else sell++;}if(close>hi)buy++;if(close<lo)sell++;if(close>d[n-1][0])buy++;else sell++;String side=(buy>=5&&buy>sell)?"🟢 BUY":(sell>=5&&sell>buy)?"🔴 SELL":"🟡 WAIT";double sl=side.contains("BUY")?close-1.5*atr:close+1.5*atr,tp=side.contains("BUY")?close+3*atr:close-3*atr;return side+" — "+s+"\n\nConfluence: "+Math.max(buy,sell)+"/7\nEntry: "+fmt(close)+"\nStop Loss: "+fmt(sl)+"\nTake Profit: "+fmt(tp)+"\nRSI: "+fmt(r)+"\nATR: "+fmt(atr)+"\n\nNo order is placed.";}
 double ema(double[][]d,int k,int p){double e=d[0][3],a=2.0/(p+1);for(int i=1;i<d.length;i++)e=d[i][3]*a+e*(1-a);return e;}
 double rsi(double[][]d,int p){double g=0,l=0;for(int i=1;i<=p;i++){double x=d[d.length-p+i-1][3]-d[d.length-p+i-2][3];if(x>0)g+=x;else l-=x;}if(l==0)return 100;return 100-100/(1+g/l);}
 double atr(double[][]d,int p){double a=0;for(int i=d.length-p;i<d.length;i++)a+=Math.max(d[i][1]-d[i][2],Math.max(Math.abs(d[i][1]-d[i-1][3]),Math.abs(d[i][2]-d[i-1][3])));return a/p;}
 String fmt(double x){return String.format(Locale.US,"%.6f",x);}
}
