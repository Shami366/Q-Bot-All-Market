# Q-Bot All Market — Android
Native Android signal app for Crypto, Forex and Stocks.

- Fetches public market candles.
- Uses the explainable 7-check confluence engine adapted from the original MT5 bot.
- Shows BUY / SELL / WAIT, entry, SL, TP, RSI and ATR.
- Signal-only: never places orders.
- GitHub Actions workflow builds the APK.

Note: public data providers can change availability/rate limits. This is an educational signal tool, not financial advice.
