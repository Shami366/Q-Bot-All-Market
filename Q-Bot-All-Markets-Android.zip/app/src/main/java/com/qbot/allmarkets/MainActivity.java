package com.qbot.allmarkets;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import java.util.Locale;

public class MainActivity extends Activity {
    private LinearLayout root;
    private Spinner marketSpinner, assetSpinner, timeframeSpinner;
    private TextView signalText, detailsText;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density); }

    private TextView text(String value, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(Color.rgb(28, 36, 52));
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(24));
        root.setBackgroundColor(Color.rgb(245, 247, 251));
        scroll.addView(root);
        setContentView(scroll);

        TextView title = text("Q-BOT  ALL MARKETS", 25, true);
        title.setTextColor(Color.rgb(25, 80, 155));
        root.addView(title);
        TextView subtitle = text("Crypto  •  Forex  •  Stocks", 15, false);
        subtitle.setPadding(0, dp(4), 0, dp(20)); root.addView(subtitle);

        addLabel("Market");
        marketSpinner = spinner(new String[]{"Crypto", "Forex", "Stocks"});
        root.addView(marketSpinner, matchWrap());

        addLabel("Asset / pair");
        assetSpinner = spinner(new String[]{"BTC/USDT", "ETH/USDT", "EUR/USD", "GBP/USD", "XAU/USD", "AAPL", "TSLA", "NVDA"});
        root.addView(assetSpinner, matchWrap());

        addLabel("Timeframe");
        timeframeSpinner = spinner(new String[]{"5 minutes", "15 minutes", "1 hour", "4 hours", "1 day"});
        root.addView(timeframeSpinner, matchWrap());

        Button analyze = new Button(this);
        analyze.setText("ANALYZE");
        analyze.setAllCaps(false);
        LinearLayout.LayoutParams bp = matchWrap(); bp.topMargin = dp(20); bp.bottomMargin = dp(16);
        root.addView(analyze, bp);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(18), dp(16), dp(18), dp(16));
        card.setBackgroundColor(Color.WHITE);
        root.addView(card, matchWrap());
        signalText = text("Signal: WAIT", 23, true);
        card.addView(signalText);
        detailsText = text("Select a market and tap Analyze.

This starter uses a demo heuristic, not live market data.", 15, false);
        detailsText.setPadding(0, dp(10), 0, 0); card.addView(detailsText);

        TextView disclaimer = text("Risk notice: Signals are educational estimates, not financial advice. Verify prices and news before trading. No automatic orders are placed.", 13, false);
        disclaimer.setPadding(0, dp(20), 0, 0); root.addView(disclaimer);

        marketSpinner.setOnItemSelectedListener(new SimpleSelectListener(() -> updateAssets()));
        analyze.setOnClickListener(v -> analyze());
    }

    private void addLabel(String s) {
        TextView t = text(s, 15, true); t.setPadding(0, dp(12), 0, dp(5)); root.addView(t);
    }
    private Spinner spinner(String[] items) {
        Spinner s = new Spinner(this);
        ArrayAdapter<String> a = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, items);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(a); return s;
    }
    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }
    private void updateAssets() {
        if (assetSpinner == null || marketSpinner == null) return;
        String market = String.valueOf(marketSpinner.getSelectedItem());
        String[] items = market.equals("Crypto") ? new String[]{"BTC/USDT","ETH/USDT","SOL/USDT","BNB/USDT"}
            : market.equals("Forex") ? new String[]{"EUR/USD","GBP/USD","USD/JPY","XAU/USD"}
            : new String[]{"AAPL","TSLA","NVDA","MSFT"};
        assetSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, items));
    }
    private void analyze() {
        String market = String.valueOf(marketSpinner.getSelectedItem());
        String asset = String.valueOf(assetSpinner.getSelectedItem());
        String tf = String.valueOf(timeframeSpinner.getSelectedItem());
        // Clearly labeled demo-only heuristic; no market feed is connected.
        int score = Math.abs((asset + tf + market).hashCode()) % 7;
        String signal = score >= 5 ? "BUY" : score <= 1 ? "SELL" : "WAIT";
        signalText.setText("Signal: " + signal + "  •  Demo");
        signalText.setTextColor(signal.equals("BUY") ? Color.rgb(18,135,83) :
                signal.equals("SELL") ? Color.rgb(190,48,48) : Color.rgb(160,110,20));
        detailsText.setText(String.format(Locale.US,
            "Market: %s\nAsset: %s\nTimeframe: %s\nDemo confluence: %d/6\n\nThis is a UI prototype only. It is NOT connected to live prices, news, RSI/EMA calculations, or a broker. Do not trade using this demo signal.",
            market, asset, tf, score));
    }

    private static class SimpleSelectListener implements AdapterView.OnItemSelectedListener {
        private final Runnable action;
        SimpleSelectListener(Runnable action) { this.action = action; }
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) { action.run(); }
        public void onNothingSelected(AdapterView<?> parent) {}
    }
}
